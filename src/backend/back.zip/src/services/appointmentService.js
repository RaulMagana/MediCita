'use strict';

const db = require('../config/database');
const { withSlotLock } = require('../utils/slotMutex');
const logger = require('../utils/logger');

async function getSlots(filters = {}) {
  let sql = 'SELECT * FROM appointment_slots WHERE 1=1';
  const params = [];
  let i = 1;

  if (filters.date)   { sql += ` AND slot_date = $${i++}`;   params.push(filters.date); }
  if (filters.status) { sql += ` AND status = $${i++}`;      params.push(filters.status); }
  if (filters.from)   { sql += ` AND slot_date >= $${i++}`;  params.push(filters.from); }
  if (filters.to)     { sql += ` AND slot_date <= $${i++}`;  params.push(filters.to); }

  sql += ' ORDER BY slot_date, slot_time';
  const { rows } = await db.query(sql, params);
  return rows;
}

async function bookSlot({ slotId, patientId, bookedBy }) {
  return withSlotLock(slotId, async () => {
    const conn = await db.connect();
    try {
      await conn.query('BEGIN');

      const { rows: slotRows } = await conn.query(
        'SELECT id, status FROM appointment_slots WHERE id = $1 FOR UPDATE',
        [slotId]
      );
      const slot = slotRows[0];
      if (!slot) {
        const err = new Error('Slot no encontrado'); err.statusCode = 404; throw err;
      }
      if (slot.status !== 'available') {
        const err = new Error('El horario ya no está disponible'); err.statusCode = 409; throw err;
      }

      await conn.query(
        `UPDATE appointment_slots SET status = 'booked', patient_id = $1, booked_by = $2 WHERE id = $3`,
        [patientId, bookedBy, slotId]
      );

      if (bookedBy === 'doctor') {
        const { rows: patRows } = await conn.query(
          'SELECT user_id FROM patients WHERE id = $1', [patientId]
        );
        if (patRows[0]) {
          await conn.query(
            `INSERT INTO notifications (user_id, message)
             VALUES ($1, 'El médico ha agendado una nueva cita para usted.')`,
            [patRows[0].user_id]
          );
        }
      }

      await conn.query('COMMIT');
      logger.info('Slot reservado', { slotId, patientId, bookedBy });

      const { rows } = await db.query('SELECT * FROM appointment_slots WHERE id = $1', [slotId]);
      return rows[0];
    } catch (err) {
      await conn.query('ROLLBACK');
      throw err;
    } finally {
      conn.release();
    }
  });
}

async function cancelAppointment({ slotId, requesterId, requesterRole }) {
  const conn = await db.connect();
  try {
    await conn.query('BEGIN');

    const { rows: slotRows } = await conn.query(
      'SELECT id, patient_id, status FROM appointment_slots WHERE id = $1 FOR UPDATE',
      [slotId]
    );
    const slot = slotRows[0];
    if (!slot) { const e = new Error('Cita no encontrada'); e.statusCode = 404; throw e; }
    if (slot.status === 'cancelled') { const e = new Error('Ya cancelada'); e.statusCode = 409; throw e; }

    if (requesterRole === 'patient') {
      const { rows } = await db.query('SELECT id FROM patients WHERE user_id = $1', [requesterId]);
      if (!rows[0] || rows[0].id !== slot.patient_id) {
        const e = new Error('No autorizado'); e.statusCode = 403; throw e;
      }
    }

    await conn.query(
      `UPDATE appointment_slots SET status = 'cancelled', patient_id = NULL, booked_by = NULL WHERE id = $1`,
      [slotId]
    );

    if (requesterRole === 'doctor' && slot.patient_id) {
      const { rows: patRows } = await conn.query(
        'SELECT user_id FROM patients WHERE id = $1', [slot.patient_id]
      );
      if (patRows[0]) {
        await conn.query(
          `INSERT INTO notifications (user_id, message)
           VALUES ($1, 'Su cita médica ha sido cancelada por el médico.')`,
          [patRows[0].user_id]
        );
      }
    }

    await conn.query('COMMIT');
    logger.info('Cita cancelada', { slotId });
  } catch (err) {
    await conn.query('ROLLBACK');
    throw err;
  } finally {
    conn.release();
  }
}

async function getPatientAppointments(patientId) {
  const { rows } = await db.query(
    `SELECT s.*, p.full_name AS patient_name
     FROM appointment_slots s
     LEFT JOIN patients p ON p.id = s.patient_id
     WHERE s.patient_id = $1
     ORDER BY s.slot_date DESC, s.slot_time DESC`,
    [patientId]
  );
  return rows;
}

module.exports = { getSlots, bookSlot, cancelAppointment, getPatientAppointments };